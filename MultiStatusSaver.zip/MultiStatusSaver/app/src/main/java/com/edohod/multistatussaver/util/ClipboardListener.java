package com.edohod.multistatussaver.util;

import android.content.ClipboardManager;

public abstract class ClipboardListener implements ClipboardManager.OnPrimaryClipChangedListener {

}
