package com.edohod.multistatussaver.interfaces;


import com.edohod.multistatussaver.model.story.TrayModel;

public interface UserListInterface {
    void userListClick(int position, TrayModel trayModel);
}
